<?php
// created: 2024-06-26 10:47:35
$dictionary["ad12d_Help_Desk"]["fields"]["ad12d_help_desk_notes"] = array (
  'name' => 'ad12d_help_desk_notes',
  'type' => 'link',
  'relationship' => 'ad12d_help_desk_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_AD12D_HELP_DESK_NOTES_FROM_NOTES_TITLE',
);
